const express = require('express');
const path = require('path');
const db = require('./db');
const app = express();
const PORT = 3000;

app.use(express.static(path.join(__dirname, '..', 'public')));
app.use(express.json());

// Get all products
app.get('/api/products', async (req, res) => {
  const products = await db.getAllProducts();
  res.json(products);
});

// Get product by id
app.get('/api/products/:id', async (req, res) => {
  const product = await db.getProductById(req.params.id);
  if (product) res.json(product);
  else res.status(404).json({ error: 'Product not found' });
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});