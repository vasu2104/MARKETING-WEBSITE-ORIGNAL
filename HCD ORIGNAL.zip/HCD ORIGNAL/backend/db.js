const sqlite3 = require('sqlite3').verbose();
const db = new sqlite3.Database('./bath_solutions.db');

// Initialize DB
db.serialize(() => {
  db.run(`
    CREATE TABLE IF NOT EXISTS products (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT,
      type TEXT,
      description TEXT,
      image TEXT,
      price REAL
    )
  `);

  // Optionally insert some sample data
  db.all('SELECT COUNT(*) as count FROM products', [], (err, rows) => {
    if (rows[0].count === 0) {
      const stmt = db.prepare('INSERT INTO products (name, type, description, image, price) VALUES (?, ?, ?, ?, ?)');
      stmt.run("Modern Shower", "Shower", "Elegant high-pressure shower.", "images/shower1.jpg", 199.99);
      stmt.run("Luxury Faucet", "Faucet", "Chrome finish, easy installation.", "images/faucet1.jpg", 89.99);
      stmt.run("Hand Shower Pro", "Hand Shower", "Flexible and powerful.", "images/handshower1.jpg", 59.99);
      stmt.finalize();
    }
  });
});

module.exports = {
  getAllProducts: () => new Promise((resolve) => {
    db.all('SELECT * FROM products', [], (err, rows) => resolve(rows));
  }),
  getProductById: (id) => new Promise((resolve) => {
    db.get('SELECT * FROM products WHERE id = ?', [id], (err, row) => resolve(row));
  }),
};