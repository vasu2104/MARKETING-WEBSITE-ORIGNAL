// For index.html: Load and display product list
if (document.getElementById('product-list')) {
  fetch('/api/products')
    .then(res => res.json())
    .then(products => {
      const container = document.getElementById('product-list');
      products.forEach(product => {
        const card = document.createElement('div');
        card.className = 'product-card';
        card.innerHTML = `
          <img src="${product.image}" alt="${product.name}">
          <h3>${product.name}</h3>
          <p>${product.type}</p>
          <p>$${product.price}</p>
          <button onclick="window.location='product.html?id=${product.id}'">Details</button>
        `;
        container.appendChild(card);
      });
    });
}

// For product.html: Load product details
if (document.getElementById('product-detail')) {
  const urlParams = new URLSearchParams(window.location.search);
  const id = urlParams.get('id');
  fetch(`/api/products/${id}`)
    .then(res => res.json())
    .then(product => {
      const detail = document.getElementById('product-detail');
      detail.innerHTML = `
        <img src="${product.image}" style="max-width:300px;" alt="${product.name}">
        <h2>${product.name}</h2>
        <h4>${product.type}</h4>
        <p>${product.description}</p>
        <p style="font-size:1.2em;"><b>Price: $${product.price}</b></p>
        <a href="index.html">← Back to Products</a>
      `;
    });
}