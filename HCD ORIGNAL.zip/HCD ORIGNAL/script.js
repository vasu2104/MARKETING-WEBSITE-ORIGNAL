// Responsive navbar toggle
document.getElementById('navToggle')?.addEventListener('click', function() {
  let navList = this.previousElementSibling;
  navList.classList.toggle('show');
});

// Quick View Modal logic
function openProductModal(title, desc, img) {
  document.getElementById('modalTitle').innerText = title;
  document.getElementById('modalDesc').innerText = desc;
  document.getElementById('modalImg').src = img;
  document.getElementById('productModal').style.display = 'flex';
}
function closeProductModal() {
  document.getElementById('productModal').style.display = 'none';
}

// Close modal when clicking outside modal-content
document.addEventListener('click', function(e) {
  var modal = document.getElementById('productModal');
  if (modal && e.target === modal) closeProductModal();
});

// Contact form validation and success
document.getElementById('contactForm')?.addEventListener('submit', function(e){
  e.preventDefault();
  document.getElementById('formSuccess').style.display = 'block';
  this.reset();
});

// Sticky navbar on scroll
window.addEventListener('scroll', function() {
  var nav = document.getElementById('navbar');
  if (window.scrollY > 60) nav?.classList.add('sticky');
  else nav?.classList.remove('sticky');
});